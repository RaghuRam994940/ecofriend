import { db } from '../firebase-config';
import { collection, getDocs, getDoc, doc, setDoc, updateDoc, increment, arrayUnion, query, where, orderBy, limit } from 'firebase/firestore';

// Get all challenges with optional filtering
export const getChallenges = async (filters = {}) => {
  try {
    let q = collection(db, 'challenges');
    
    // Apply filters if provided
    if (filters.category) {
      q = query(q, where('category', '==', filters.category));
    }
    if (filters.difficulty) {
      q = query(q, where('difficulty', '==', filters.difficulty));
    }
    
    const querySnapshot = await getDocs(q);
    const challenges = [];
    
    querySnapshot.forEach((doc) => {
      challenges.push({
        id: doc.id,
        ...doc.data()
      });
    });
    
    return { success: true, data: challenges };
  } catch (error) {
    return { success: false, error: error.message };
  }
};

// Get a single challenge by ID
export const getChallenge = async (challengeId) => {
  try {
    const challengeDoc = await getDoc(doc(db, 'challenges', challengeId));
    
    if (challengeDoc.exists()) {
      return { 
        success: true, 
        data: { id: challengeDoc.id, ...challengeDoc.data() } 
      };
    } else {
      return { success: false, error: 'Challenge not found' };
    }
  } catch (error) {
    return { success: false, error: error.message };
  }
};

// Complete a challenge
export const completeChallenge = async (userId, challengeId) => {
  try {
    const challengeRef = doc(db, 'challenges', challengeId);
    const challengeDoc = await getDoc(challengeRef);
    
    if (!challengeDoc.exists()) {
      return { success: false, error: 'Challenge not found' };
    }
    
    const challenge = challengeDoc.data();
    const userRef = doc(db, 'users', userId);
    
    // Update user's points and completed challenges
    await updateDoc(userRef, {
      ecoPoints: increment(challenge.points),
      completedChallenges: arrayUnion({
        challengeId,
        completedAt: new Date().toISOString(),
        pointsEarned: challenge.points
      }),
      lastActivity: new Date().toISOString()
    });
    
    // Update challenge completion count
    await updateDoc(challengeRef, {
      completedCount: increment(1)
    });
    
    return { 
      success: true, 
      data: { 
        pointsEarned: challenge.points,
        newLevel: await checkLevelUp(userId)
      } 
    };
  } catch (error) {
    return { success: false, error: error.message };
  }
};

// Check if user leveled up
const checkLevelUp = async (userId) => {
  const userRef = doc(db, 'users', userId);
  const userDoc = await getDoc(userRef);
  const user = userDoc.data();
  
  const newLevel = Math.floor(user.ecoPoints / 100) + 1;
  
  if (newLevel > user.level) {
    await updateDoc(userRef, { level: newLevel });
    return newLevel;
  }
  
  return null;
};

// Get leaderboard
export const getLeaderboard = async (limitCount = 10) => {
  try {
    const q = query(
      collection(db, 'users'),
      orderBy('ecoPoints', 'desc'),
      limit(limitCount)
    );
    
    const querySnapshot = await getDocs(q);
    const leaderboard = [];
    
    querySnapshot.forEach((doc) => {
      leaderboard.push({
        id: doc.id,
        ...doc.data()
      });
    });
    
    return { success: true, data: leaderboard };
  } catch (error) {
    return { success: false, error: error.message };
  }
};

// Add a review to a challenge
export const addChallengeReview = async (challengeId, userId, review) => {
  try {
    const reviewRef = doc(collection(db, 'challenges', challengeId, 'reviews'));
    
    await setDoc(reviewRef, {
      ...review,
      userId,
      challengeId,
      createdAt: new Date().toISOString(),
      approved: false // Admin needs to approve reviews
    });
    
    return { success: true };
  } catch (error) {
    return { success: false, error: error.message };
  }
};

// Get reviews for a challenge
export const getChallengeReviews = async (challengeId, approvedOnly = true) => {
  try {
    let q = collection(db, 'challenges', challengeId, 'reviews');
    
    if (approvedOnly) {
      q = query(q, where('approved', '==', true));
    }
    
    q = query(q, orderBy('createdAt', 'desc'));
    
    const querySnapshot = await getDocs(q);
    const reviews = [];
    
    querySnapshot.forEach((doc) => {
      reviews.push({
        id: doc.id,
        ...doc.data()
      });
    });
    
    return { success: true, data: reviews };
  } catch (error) {
    return { success: false, error: error.message };
  }
};
