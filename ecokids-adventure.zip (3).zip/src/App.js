import React, { useState, useEffect } from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import { auth } from './firebase-config';
import { onAuthStateChanged } from 'firebase/auth';

// Layout Components
import Header from './components/layout/Header';
import Footer from './components/layout/Footer';

// Auth Components
import Login from './components/auth/Login';
import Signup from './components/auth/Signup';
import ForgotPassword from './components/auth/ForgotPassword';

// Main Components
import Dashboard from './components/dashboard/Dashboard';
import ChallengeList from './components/challenges/ChallengeList';
import ChallengeDetail from './components/challenges/ChallengeDetail';
import Profile from './components/profile/Profile';
import Leaderboard from './components/leaderboard/Leaderboard';

// Admin Components
import AdminDashboard from './components/admin/AdminDashboard';
import ChallengeForm from './components/admin/ChallengeForm';

// Context
import { AuthProvider } from './contexts/AuthContext';

// Protected Route Component
const ProtectedRoute = ({ children, adminOnly = false }) => {
  const user = auth.currentUser;
  
  if (!user) {
    return <Navigate to="/login" replace />;
  }
  
  if (adminOnly && user.uid !== process.env.REACT_APP_ADMIN_UID) {
    return <Navigate to="/dashboard" replace />;
  }
  
  return children;
};

function App() {
  const [currentUser, setCurrentUser] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, (user) => {
      setCurrentUser(user);
      setLoading(false);
    });

    return () => unsubscribe();
  }, []);

  if (loading) {
    return (
      <div className="loading-screen">
        <div className="spinner"></div>
      </div>
    );
  }

  return (
    <AuthProvider value={{ currentUser }}>
      <Router>
        <div className="app">
          <Header />
          <main className="main-content">
            <Routes>
              {/* Public Routes */}
              <Route path="/" element={<Navigate to="/challenges" replace />} />
              <Route path="/login" element={!currentUser ? <Login /> : <Navigate to="/dashboard" />} />
              <Route path="/signup" element={!currentUser ? <Signup /> : <Navigate to="/dashboard" />} />
              <Route path="/forgot-password" element={<ForgotPassword />} />
              
              {/* Protected Routes */}
              <Route path="/dashboard" element={
                <ProtectedRoute>
                  <Dashboard />
                </ProtectedRoute>
              } />
              
              <Route path="/challenges" element={
                <ChallengeList />
              } />
              
              <Route path="/challenges/:id" element={
                <ChallengeDetail />
              } />
              
              <Route path="/profile" element={
                <ProtectedRoute>
                  <Profile />
                </ProtectedRoute>
              } />
              
              <Route path="/leaderboard" element={
                <Leaderboard />
              } />
              
              {/* Admin Routes */}
              <Route path="/admin" element={
                <ProtectedRoute adminOnly={true}>
                  <AdminDashboard />
                </ProtectedRoute>
              } />
              
              <Route path="/admin/challenges/new" element={
                <ProtectedRoute adminOnly={true}>
                  <ChallengeForm />
                </ProtectedRoute>
              } />
              
              <Route path="/admin/challenges/:id/edit" element={
                <ProtectedRoute adminOnly={true}>
                  <ChallengeForm />
                </ProtectedRoute>
              } />
              
              {/* 404 Route */}
              <Route path="*" element={
                <div className="not-found">
                  <h2>404 - Page Not Found</h2>
                  <p>The page you're looking for doesn't exist.</p>
                </div>
              } />
            </Routes>
          </main>
          <Footer />
        </div>
      </Router>
    </AuthProvider>
  );
}

export default App;
