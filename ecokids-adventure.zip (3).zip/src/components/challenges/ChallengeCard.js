import React from 'react';
import { Link } from 'react-router-dom';
import { completeChallenge } from '../../services/challengeService';
import { auth } from '../../firebase-config';

const ChallengeCard = ({ challenge, onComplete }) => {
  const { id, title, description, points, category, difficulty, completedCount, icon = '🌱' } = challenge;
  
  const handleComplete = async () => {
    if (!auth.currentUser) {
      // Redirect to login if not authenticated
      window.location.href = '/login?redirect=' + encodeURIComponent(window.location.pathname);
      return;
    }
    
    try {
      const result = await completeChallenge(auth.currentUser.uid, id);
      if (result.success) {
        onComplete && onComplete(result.data);
      } else {
        console.error('Error completing challenge:', result.error);
      }
    } catch (error) {
      console.error('Error completing challenge:', error);
    }
  };

  const getDifficultyColor = () => {
    switch(difficulty) {
      case 'easy': return '#4CAF50';
      case 'medium': return '#FFC107';
      case 'hard': return '#F44336';
      default: return '#9E9E9E';
    }
  };

  const getCategoryIcon = () => {
    const icons = {
      'recycling': '♻️',
      'energy': '⚡',
      'water': '💧',
      'waste': '🗑️',
      'biodiversity': '🦋',
      'community': '👥'
    };
    return icons[category] || '🌍';
  };

  return (
    <div className="challenge-card">
      <div className="challenge-header">
        <div className="challenge-icon">{icon || getCategoryIcon()}</div>
        <div className="challenge-points">
          <span className="points-badge">{points} pts</span>
          <span 
            className="difficulty-badge"
            style={{ backgroundColor: getDifficultyColor() }}
          >
            {difficulty}
          </span>
        </div>
      </div>
      
      <div className="challenge-content">
        <h3>{title}</h3>
        <p>{description}</p>
        
        <div className="challenge-meta">
          <span className="category">
            {getCategoryIcon()} {category}
          </span>
          <span className="completed-count">
            ✅ {completedCount || 0} completed
          </span>
        </div>
      </div>
      
      <div className="challenge-actions">
        <Link to={`/challenges/${id}`} className="btn btn-outline">
          View Details
        </Link>
        <button 
          className="btn btn-primary"
          onClick={handleComplete}
        >
          Mark as Complete
        </button>
      </div>
    </div>
  );
};

export default ChallengeCard;
