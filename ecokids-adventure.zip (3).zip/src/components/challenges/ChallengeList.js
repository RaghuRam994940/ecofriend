import React, { useState, useEffect } from 'react';
import { getChallenges } from '../../services/challengeService';
import ChallengeCard from './ChallengeCard';
import './ChallengeList.css';

const ChallengeList = () => {
  const [challenges, setChallenges] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [filters, setFilters] = useState({
    category: '',
    difficulty: '',
    sortBy: 'popular'
  });

  const categories = [
    { value: '', label: 'All Categories' },
    { value: 'recycling', label: '♻️ Recycling' },
    { value: 'energy', label: '⚡ Energy' },
    { value: 'water', label: '💧 Water' },
    { value: 'waste', label: '🗑️ Waste Reduction' },
    { value: 'biodiversity', label: '🦋 Biodiversity' },
    { value: 'community', label: '👥 Community' }
  ];

  const difficulties = [
    { value: '', label: 'All Levels' },
    { value: 'easy', label: 'Easy' },
    { value: 'medium', label: 'Medium' },
    { value: 'hard', label: 'Hard' }
  ];

  const sortOptions = [
    { value: 'popular', label: 'Most Popular' },
    { value: 'newest', label: 'Newest First' },
    { value: 'points', label: 'Most Points' }
  ];

  useEffect(() => {
    const fetchChallenges = async () => {
      try {
        setLoading(true);
        const { success, data, error } = await getChallenges(filters);
        
        if (success) {
          // Sort challenges based on selected option
          let sortedChallenges = [...data];
          switch(filters.sortBy) {
            case 'newest':
              sortedChallenges.sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));
              break;
            case 'points':
              sortedChallenges.sort((a, b) => b.points - a.points);
              break;
            default: // popular
              sortedChallenges.sort((a, b) => (b.completedCount || 0) - (a.completedCount || 0));
          }
          
          setChallenges(sortedChallenges);
        } else {
          setError(error || 'Failed to load challenges');
        }
      } catch (err) {
        setError('An error occurred while loading challenges');
        console.error('Error fetching challenges:', err);
      } finally {
        setLoading(false);
      }
    };

    fetchChallenges();
  }, [filters]);

  const handleFilterChange = (e) => {
    const { name, value } = e.target;
    setFilters(prev => ({
      ...prev,
      [name]: value
    }));
  };

  const handleChallengeComplete = (challengeId, result) => {
    // Update the completed count in the UI
    setChallenges(prevChallenges => 
      prevChallenges.map(challenge => 
        challenge.id === challengeId 
          ? { 
              ...challenge, 
              completedCount: (challenge.completedCount || 0) + 1,
              completed: true 
            } 
          : challenge
      )
    );
    
    // Show success message or update points
    if (result && result.pointsEarned) {
      // You can add a toast notification here
      console.log(`Earned ${result.pointsEarned} points!`);
      if (result.newLevel) {
        console.log(`Level up! You're now level ${result.newLevel}!`);
      }
    }
  };

  if (loading && challenges.length === 0) {
    return (
      <div className="loading-container">
        <div className="spinner"></div>
        <p>Loading challenges...</p>
      </div>
    );
  }

  if (error) {
    return (
      <div className="error-container">
        <p>⚠️ {error}</p>
        <button 
          onClick={() => window.location.reload()}
          className="btn btn-outline"
        >
          Try Again
        </button>
      </div>
    );
  }

  return (
    <div className="challenge-list-container">
      <div className="challenge-filters">
        <div className="filter-group">
          <label htmlFor="category">Category:</label>
          <select 
            id="category" 
            name="category"
            value={filters.category}
            onChange={handleFilterChange}
            className="filter-select"
          >
            {categories.map(cat => (
              <option key={cat.value} value={cat.value}>
                {cat.label}
              </option>
            ))}
          </select>
        </div>
        
        <div className="filter-group">
          <label htmlFor="difficulty">Difficulty:</label>
          <select 
            id="difficulty" 
            name="difficulty"
            value={filters.difficulty}
            onChange={handleFilterChange}
            className="filter-select"
          >
            {difficulties.map(diff => (
              <option key={diff.value} value={diff.value}>
                {diff.label}
              </option>
            ))}
          </select>
        </div>
        
        <div className="filter-group">
          <label htmlFor="sortBy">Sort By:</label>
          <select 
            id="sortBy" 
            name="sortBy"
            value={filters.sortBy}
            onChange={handleFilterChange}
            className="filter-select"
          >
            {sortOptions.map(option => (
              <option key={option.value} value={option.value}>
                {option.label}
              </option>
            ))}
          </select>
        </div>
      </div>
      
      {challenges.length === 0 ? (
        <div className="no-results">
          <p>No challenges found matching your filters.</p>
          <button 
            onClick={() => setFilters({ category: '', difficulty: '', sortBy: 'popular' })}
            className="btn btn-outline"
          >
            Clear Filters
          </button>
        </div>
      ) : (
        <div className="challenges-grid">
          {challenges.map(challenge => (
            <ChallengeCard 
              key={challenge.id} 
              challenge={challenge}
              onComplete={(result) => handleChallengeComplete(challenge.id, result)}
            />
          ))}
        </div>
      )}
    </div>
  );
};

export default ChallengeList;
