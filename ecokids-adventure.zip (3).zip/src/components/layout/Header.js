import React from 'react';
import { Link, useLocation, useNavigate } from 'react-router-dom';
import { auth } from '../../firebase-config';
import { signOut } from 'firebase/auth';
import { useAuth } from '../../contexts/AuthContext';
import './Header.css';

const Header = () => {
  const { currentUser, isAdmin } = useAuth();
  const location = useLocation();
  const navigate = useNavigate();

  const handleLogout = async () => {
    try {
      await signOut(auth);
      navigate('/login');
    } catch (error) {
      console.error('Failed to log out', error);
    }
  };

  const isActive = (path) => {
    return location.pathname === path ? 'active' : '';
  };

  return (
    <header className="app-header">
      <div className="header-container">
        <div className="logo">
          <Link to="/" className="logo-link">
            <span role="img" aria-label="Earth">🌍</span>
            <h1>EcoKids Adventure</h1>
          </Link>
        </div>
        
        <nav className="main-nav">
          <ul className="nav-links">
            <li className={isActive('/challenges')}>
              <Link to="/challenges">Challenges</Link>
            </li>
            <li className={isActive('/leaderboard')}>
              <Link to="/leaderboard">Leaderboard</Link>
            </li>
            {isAdmin && (
              <li className={isActive('/admin')}>
                <Link to="/admin">Admin</Link>
              </li>
            )}
          </ul>
        </nav>
        
        <div className="user-actions">
          {currentUser ? (
            <div className="user-menu">
              <div className="user-avatar">
                {currentUser.photoURL ? (
                  <img 
                    src={currentUser.photoURL} 
                    alt={currentUser.displayName || 'User'} 
                    className="avatar"
                  />
                ) : (
                  <div className="avatar-placeholder">
                    {currentUser.displayName?.charAt(0).toUpperCase() || '👤'}
                  </div>
                )}
                <span className="user-name">
                  {currentUser.displayName || 'User'}
                </span>
              </div>
              <div className="dropdown-menu">
                <Link to="/profile" className="dropdown-item">
                  <span>👤</span> My Profile
                </Link>
                <Link to="/dashboard" className="dropdown-item">
                  <span>📊</span> Dashboard
                </Link>
                <button onClick={handleLogout} className="dropdown-item">
                  <span>🚪</span> Logout
                </button>
              </div>
            </div>
          ) : (
            <div className="auth-buttons">
              <Link to="/login" className="btn btn-outline">
                Login
              </Link>
              <Link to="/signup" className="btn btn-primary">
                Sign Up
              </Link>
            </div>
          )}
        </div>
        
        <button className="mobile-menu-button">
          <span></span>
          <span></span>
          <span></span>
        </button>
      </div>
    </header>
  );
};

export default Header;
