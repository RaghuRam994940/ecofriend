import React from 'react';
import { Link } from 'react-router-dom';
import './Footer.css';

const Footer = () => {
  const currentYear = new Date().getFullYear();
  
  return (
    <footer className="app-footer">
      <div className="footer-container">
        <div className="footer-section">
          <h3>EcoKids Adventure</h3>
          <p>Teaching kids about environmental responsibility through fun and interactive challenges.</p>
          <div className="social-links">
            <a href="https://facebook.com" target="_blank" rel="noopener noreferrer" aria-label="Facebook">
              <span role="img" aria-hidden="true">📘</span>
            </a>
            <a href="https://twitter.com" target="_blank" rel="noopener noreferrer" aria-label="Twitter">
              <span role="img" aria-hidden="true">🐦</span>
            </a>
            <a href="https://instagram.com" target="_blank" rel="noopener noreferrer" aria-label="Instagram">
              <span role="img" aria-hidden="true">📸</span>
            </a>
          </div>
        </div>
        
        <div className="footer-section">
          <h4>Quick Links</h4>
          <ul className="footer-links">
            <li><Link to="/challenges">Challenges</Link></li>
            <li><Link to="/leaderboard">Leaderboard</Link></li>
            <li><Link to="/about">About Us</Link></li>
            <li><Link to="/contact">Contact</Link></li>
          </ul>
        </div>
        
        <div className="footer-section">
          <h4>Resources</h4>
          <ul className="footer-links">
            <li><a href="/blog" target="_blank" rel="noopener noreferrer">Blog</a></li>
            <li><a href="/faq" target="_blank" rel="noopener noreferrer">FAQ</a></li>
            <li><a href="/privacy" target="_blank" rel="noopener noreferrer">Privacy Policy</a></li>
            <li><a href="/terms" target="_blank" rel="noopener noreferrer">Terms of Service</a></li>
          </ul>
        </div>
        
        <div className="footer-section">
          <h4>Newsletter</h4>
          <p>Subscribe for eco-tips and updates!</p>
          <form className="newsletter-form">
            <input 
              type="email" 
              placeholder="Your email" 
              aria-label="Email for newsletter subscription"
              required 
            />
            <button type="submit">Subscribe</button>
          </form>
        </div>
      </div>
      
      <div className="footer-bottom">
        <p>&copy; {currentYear} EcoKids Adventure. All rights reserved.</p>
        <div className="footer-credits">
          Made with <span role="img" aria-label="love">❤️</span> for a greener planet
        </div>
      </div>
    </footer>
  );
};

export default Footer;
