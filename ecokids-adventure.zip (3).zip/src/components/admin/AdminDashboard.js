import React, { useState, useEffect } from 'react';
import { Link, useNavigate, useLocation } from 'react-router-dom';
import { collection, getDocs, query, where, getCountFromServer } from 'firebase/firestore';
import { db } from '../../firebase-config';
import './AdminDashboard.css';

const AdminDashboard = () => {
  const [stats, setStats] = useState({
    totalUsers: 0,
    activeUsers: 0,
    totalChallenges: 0,
    pendingReviews: 0,
    recentActivity: []
  });
  const [loading, setLoading] = useState(true);
  const [activeTab, setActiveTab] = useState('overview');
  const navigate = useNavigate();
  const location = useLocation();

  // Check for tab in URL
  useEffect(() => {
    const tab = location.pathname.split('/').pop();
    if (['overview', 'challenges', 'users', 'reviews', 'analytics'].includes(tab)) {
      setActiveTab(tab);
    }
  }, [location]);

  useEffect(() => {
    const fetchStats = async () => {
      try {
        setLoading(true);
        
        // Get total users count
        const usersSnapshot = await getCountFromServer(collection(db, 'users'));
        
        // Get active users (last 30 days)
        const thirtyDaysAgo = new Date();
        thirtyDaysAgo.setDate(thirtyDaysAgo.getDate() - 30);
        const activeUsersQuery = query(
          collection(db, 'users'),
          where('lastLogin', '>=', thirtyDaysAgo.toISOString())
        );
        const activeUsersSnapshot = await getCountFromServer(activeUsersQuery);
        
        // Get total challenges count
        const challengesSnapshot = await getCountFromServer(collection(db, 'challenges'));
        
        // Get pending reviews count
        const reviewsQuery = query(
          collectionGroup(db, 'reviews'),
          where('approved', '==', false)
        );
        const reviewsSnapshot = await getCountFromServer(reviewsQuery);
        
        // Get recent activity (simplified for example)
        const recentActivity = [];
        
        setStats({
          totalUsers: usersSnapshot.data().count,
          activeUsers: activeUsersSnapshot.data().count,
          totalChallenges: challengesSnapshot.data().count,
          pendingReviews: reviewsSnapshot.data().count,
          recentActivity
        });
        
      } catch (error) {
        console.error('Error fetching admin stats:', error);
      } finally {
        setLoading(false);
      }
    };
    
    fetchStats();
  }, []);

  const navigateToTab = (tab) => {
    setActiveTab(tab);
    navigate(`/admin/${tab}`);
  };

  const renderTabContent = () => {
    switch(activeTab) {
      case 'challenges':
        return <ChallengesTab />;
      case 'users':
        return <UsersTab />;
      case 'reviews':
        return <ReviewsTab />;
      case 'analytics':
        return <AnalyticsTab />;
      default:
        return <OverviewTab stats={stats} loading={loading} />;
    }
  };

  if (loading && activeTab === 'overview') {
    return (
      <div className="admin-loading">
        <div className="spinner"></div>
        <p>Loading admin dashboard...</p>
      </div>
    );
  }

  return (
    <div className="admin-dashboard">
      <div className="admin-header">
        <h1>Admin Dashboard</h1>
        <div className="admin-actions">
          <Link to="/admin/challenges/new" className="btn btn-primary">
            + New Challenge
          </Link>
        </div>
      </div>
      
      <div className="admin-tabs">
        <button 
          className={`tab ${activeTab === 'overview' ? 'active' : ''}`}
          onClick={() => navigateToTab('overview')}
        >
          <span className="tab-icon">📊</span> Overview
        </button>
        <button 
          className={`tab ${activeTab === 'challenges' ? 'active' : ''}`}
          onClick={() => navigateToTab('challenges')}
        >
          <span className="tab-icon">🎯</span> Challenges
        </button>
        <button 
          className={`tab ${activeTab === 'users' ? 'active' : ''}`}
          onClick={() => navigateToTab('users')}
        >
          <span className="tab-icon">👥</span> Users
        </button>
        <button 
          className={`tab ${activeTab === 'reviews' ? 'active' : ''}`}
          onClick={() => navigateToTab('reviews')}
        >
          <span className="tab-icon">⭐</span> Reviews
          {stats.pendingReviews > 0 && (
            <span className="badge">{stats.pendingReviews}</span>
          )}
        </button>
        <button 
          className={`tab ${activeTab === 'analytics' ? 'active' : ''}`}
          onClick={() => navigateToTab('analytics')}
        >
          <span className="tab-icon">📈</span> Analytics
        </button>
      </div>
      
      <div className="admin-content">
        {renderTabContent()}
      </div>
    </div>
  );
};

// Tab Components
const OverviewTab = ({ stats, loading }) => (
  <div className="overview-tab">
    <div className="stats-grid">
      <StatCard 
        icon="👥" 
        title="Total Users" 
        value={stats.totalUsers} 
        change="+12%"
        changeType="increase"
      />
      <StatCard 
        icon="🚀" 
        title="Active Users" 
        value={stats.activeUsers} 
        change="+5%"
        changeType="increase"
      />
      <StatCard 
        icon="🎯" 
        title="Challenges" 
        value={stats.totalChallenges} 
        change="+3"
        changeType="neutral"
      />
      <StatCard 
        icon="⭐" 
        title="Pending Reviews" 
        value={stats.pendingReviews} 
        change={stats.pendingReviews > 0 ? 'Needs attention' : 'All clear'}
        changeType={stats.pendingReviews > 0 ? 'decrease' : 'neutral'}
      />
    </div>
    
    <div className="recent-activity">
      <h3>Recent Activity</h3>
      {stats.recentActivity.length > 0 ? (
        <div className="activity-list">
          {stats.recentActivity.map((activity, index) => (
            <div key={index} className="activity-item">
              <div className="activity-icon">
                {getActivityIcon(activity.type)}
              </div>
              <div className="activity-details">
                <p className="activity-message">{activity.message}</p>
                <span className="activity-time">{activity.time}</span>
              </div>
            </div>
          ))}
        </div>
      ) : (
        <div className="no-activity">
          <p>No recent activity to display</p>
        </div>
      )}
    </div>
  </div>
);

const ChallengesTab = () => (
  <div className="challenges-tab">
    <div className="tab-header">
      <h2>Manage Challenges</h2>
      <div className="tab-actions">
        <input 
          type="text" 
          placeholder="Search challenges..." 
          className="search-input"
        />
        <select className="filter-select">
          <option>All Categories</option>
          <option>Recycling</option>
          <option>Energy</option>
          <option>Water</option>
        </select>
      </div>
    </div>
    <div className="challenges-list">
      {/* Challenge list will be populated here */}
      <p className="empty-state">Loading challenges...</p>
    </div>
  </div>
);

const UsersTab = () => (
  <div className="users-tab">
    <h2>User Management</h2>
    <p className="empty-state">User management interface will be implemented here.</p>
  </div>
);

const ReviewsTab = () => (
  <div className="reviews-tab">
    <h2>Pending Reviews</h2>
    <p className="empty-state">Review moderation interface will be implemented here.</p>
  </div>
);

const AnalyticsTab = () => (
  <div className="analytics-tab">
    <h2>Analytics Dashboard</h2>
    <div className="analytics-grid">
      <div className="analytics-card">
        <h3>User Growth</h3>
        <div className="placeholder-chart">📈 User growth chart will be displayed here</div>
      </div>
      <div className="analytics-card">
        <h3>Challenge Completion</h3>
        <div className="placeholder-chart">📊 Challenge completion metrics will be displayed here</div>
      </div>
    </div>
  </div>
);

// Helper Components
const StatCard = ({ icon, title, value, change, changeType }) => (
  <div className="stat-card">
    <div className="stat-icon">{icon}</div>
    <div className="stat-details">
      <h3>{title}</h3>
      <p className="stat-value">{value.toLocaleString()}</p>
      <p className={`stat-change ${changeType}`}>
        {changeType === 'increase' ? '↑' : changeType === 'decrease' ? '↓' : '→'}
        {change}
      </p>
    </div>
  </div>
);

const getActivityIcon = (type) => {
  const icons = {
    'user_signup': '👋',
    'challenge_complete': '✅',
    'review_submitted': '⭐',
    'badge_earned': '🏆',
    'default': '🔔'
  };
  return icons[type] || icons['default'];
};

export default AdminDashboard;
